const LIXX_DEP = 7942136966;

const GH = {
  owner: "lixxfish",
  repo: "Maintenance-",
  branch: "main",
  token: "",
  path: "maintenance.json",
};

const MAINT_MSG = "🚧 Akses ditolak, bot sedang maintenance.";

async function ghRequest(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      "Accept": "application/vnd.github+json",
      "Authorization": `Bearer ${GH.token}`,
      "X-GitHub-Api-Version": "2022-11-28",
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });

  // Kalau GET dan file belum ada → balikin null (jangan throw)
  if ((!options.method || options.method === "GET") && res.status === 404) {
    return null;
  }

  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { json = { raw: text }; }

  if (!res.ok) throw new Error(`GitHub Error ${res.status}: ${JSON.stringify(json)}`);
  return json;
}

async function getFile() {
  const url = `https://api.github.com/repos/${GH.owner}/${GH.repo}/contents/${encodeURIComponent(GH.path)}?ref=${encodeURIComponent(GH.branch)}`;
  return ghRequest(url); // bisa null
}

async function writeState(enabled) {
  const existing = await getFile();
  const sha = existing?.sha;

  const body = {
    enabled: !!enabled,
    updatedAt: new Date().toISOString(),
  };

  const content = Buffer.from(JSON.stringify(body, null, 2), "utf8").toString("base64");

  const url = `https://api.github.com/repos/${GH.owner}/${GH.repo}/contents/${encodeURIComponent(GH.path)}`;
  return ghRequest(url, {
    method: "PUT",
    body: JSON.stringify({
      message: `maintenance ${enabled ? "ON" : "OFF"}`,
      content,
      branch: GH.branch,
      ...(sha ? { sha } : {}),
    }),
  });
}

async function readState() {
  const data = await getFile();
  if (!data) return false; // file belum ada = OFF

  const decoded = Buffer.from(data.content, "base64").toString("utf8");
  let json;
  try { json = JSON.parse(decoded); } catch { json = {}; }
  return !!json.enabled;
}

async function maintanceGuard(ctx) {
  if (ctx.from?.id === LIXX_DEP) return true;
  const isOn = await readState();
  if (isOn) {
    await ctx.reply(MAINT_MSG);
    return false;
  }
  return true;
}

// alias biar gak ketuker nama
const maintenanceGuard = maintanceGuard;

module.exports = {
  LIXX_DEP,
  writeState,
  readState,
  maintanceGuard,
  maintenanceGuard,
};