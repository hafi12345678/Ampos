module.exports = {
  VPS_IP: "209.97.180.74",
  PANEL_PORT: 3133,
  FULL_URL: "http://209.97.180.74:3133"
};